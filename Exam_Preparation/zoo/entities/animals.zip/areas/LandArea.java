package zoo.entities.areas;

public class LandArea extends BaseArea{
    public LandArea(String name) {
        super(name, 25);
    }
}
